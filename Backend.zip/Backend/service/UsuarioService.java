package com.cefet.chamapro.service;

import com.cefet.chamapro.dto.UsuarioRequestDTO;
import com.cefet.chamapro.dto.UsuarioResponseDTO;
import com.cefet.chamapro.entity.Usuario;
import com.cefet.chamapro.entity.Endereco;
import com.cefet.chamapro.repository.UsuarioRepository;
import com.cefet.chamapro.repository.EnderecoRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository repository;
    private final EnderecoRepository enderecoRepository;

    public UsuarioResponseDTO criar(UsuarioRequestDTO dto) {
        if (repository.existsByEmail(dto.email())) {
            throw new IllegalArgumentException("Email já cadastrado");
        }
        if (repository.existsByCpf(dto.cpf())) {
            throw new IllegalArgumentException("CPF já cadastrado");
        }

        Usuario usuario = new Usuario();
        usuario.setNome(dto.nome());
        usuario.setEmail(dto.email());
        usuario.setSenha(dto.senha());
        usuario.setCpf(dto.cpf());
        usuario.setDtNasc(dto.dtNasc());
        usuario.setDtConta(new Date());
        usuario.setNota(dto.nota());
        usuario.setTipo(dto.tipo());

        Usuario salvo = repository.save(usuario);
        return toResponseDTO(salvo);
    }

    public UsuarioResponseDTO buscarPorId(String id) {
        Usuario usuario = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Usuário não encontrado"));
        return toResponseDTO(usuario);
    }

    public List<UsuarioResponseDTO> listarTodos() {
        return repository.findAll().stream()
                .map(this::toResponseDTO)
                .toList();
    }

    public UsuarioResponseDTO atualizar(String id, UsuarioRequestDTO dto) {
        Usuario usuario = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Usuário não encontrado"));

        usuario.setNome(dto.nome());
        usuario.setEmail(dto.email());
        usuario.setSenha(dto.senha());
        usuario.setCpf(dto.cpf());
        usuario.setDtNasc(dto.dtNasc());
        usuario.setNota(dto.nota());
        usuario.setTipo(dto.tipo());

        Usuario atualizado = repository.save(usuario);
        return toResponseDTO(atualizado);
    }

    public void deletar(String id) {
        if (!repository.existsById(id)) {
            throw new EntityNotFoundException("Usuário não encontrado");
        }
        repository.deleteById(id);
    }

    private Usuario buscarUsuarioPorId(String id) {
        return repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Usuário não encontrado"));
    }

    public void alterarSenha(String id, String senha) {
        if (senha == null || senha.isBlank()) {
            throw new IllegalArgumentException("Senha é obrigatória");
        }
        Usuario usuario = buscarUsuarioPorId(id);
        usuario.setSenha(senha);
        repository.save(usuario);
    }

    public void alterarCep(String id, String cep) {
        if (cep == null || cep.isBlank()) {
            throw new IllegalArgumentException("CEP é obrigatório");
        }
        List<Endereco> enderecos = enderecoRepository.findByUsuarioId(id);
        if (enderecos.isEmpty()) {
            throw new EntityNotFoundException("Endereço do usuário não encontrado");
        }
        enderecos.forEach(endereco -> endereco.setCep(cep));
        enderecoRepository.saveAll(enderecos);
    }

    private UsuarioResponseDTO toResponseDTO(Usuario usuario) {
        return new UsuarioResponseDTO(
                usuario.getId(),
                usuario.getNome(),
                usuario.getEmail(),
                usuario.getDtNasc(),
                usuario.getDtConta(),
                usuario.getNota()
        );
    }
}