package com.cefet.chamapro.controller;

import com.cefet.chamapro.dto.ClienteRequestDTO;
import com.cefet.chamapro.dto.EnderecoRequestDTO;
import com.cefet.chamapro.dto.ProfissionalRequestDTO;
import com.cefet.chamapro.dto.UsuarioRequestDTO;
import com.cefet.chamapro.dto.UsuarioResponseDTO;
import com.cefet.chamapro.service.UsuarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuarios")
@CrossOrigin(origins = {"http://localhost:8100", "http://localhost:4200"})
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioService service;
    private EnderecoController enderecoController;
    private ProfissionalController profissionalController;
    private ClienteController clienteController;

    @PostMapping
    public ResponseEntity<UsuarioResponseDTO> criar(@RequestBody @Valid UsuarioRequestDTO dto) {
        UsuarioResponseDTO criado = service.criar(dto);
        EnderecoRequestDTO endereco = new EnderecoRequestDTO();
        endereco.setCep(dto.endereco().getCep());
        endereco.setIdUsuario(dto.usuarioId());

        enderecoController.inserir(endereco);

        if (dto.tipo() == "PROFISSIONAL"){
            ProfissionalRequestDTO proRequestDTO = new ProfissionalRequestDTO(dto.usuarioId());
            profissionalController.inserir(proRequestDTO);
        } else {
            ClienteRequestDTO cliRequestDTO = new ClienteRequestDTO(dto.usuarioId());
            clienteController.criar(cliRequestDTO);
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(criado);
    }

    @GetMapping
    public ResponseEntity<List<UsuarioResponseDTO>> listarTodos() {
        return ResponseEntity.ok(service.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UsuarioResponseDTO> buscarPorId(@PathVariable String id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<UsuarioResponseDTO> atualizar(@PathVariable String id, @RequestBody @Valid UsuarioRequestDTO dto) {
        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable String id) {
        service.deletar(id);
        return ResponseEntity.noContent().build();
    }
}