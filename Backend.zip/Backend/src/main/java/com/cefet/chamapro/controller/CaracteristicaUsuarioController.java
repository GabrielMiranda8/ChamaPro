package com.cefet.chamapro.controller;

public class CaracteristicaUsuarioController {

}
