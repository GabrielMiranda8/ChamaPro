import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {
  IonContent, IonItem, IonLabel, IonInput, IonButton, IonIcon,
  IonNote, IonToggle, IonSelect, IonSelectOption, IonDatetime, ToastController,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  arrowBackOutline, eyeOutline, eyeOffOutline,
  personOutline, mailOutline, lockClosedOutline,
  calendarOutline, cardOutline, locationOutline,
  briefcaseOutline, personAddOutline,
} from 'ionicons/icons';
import { NavController } from '@ionic/angular';
import { UsuarioModel } from 'src/app/model/usuario.model';
import { UsuarioService } from 'src/app/services/usuario.service';
import { CaracteristicaModel } from 'src/app/model/caracteristica.model';
import { CaracteristicaService } from 'src/app/services/caracteristica.service';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.page.html',
  styleUrls: ['./cadastro.page.scss'],
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule, RouterModule,
    IonContent, IonItem, IonLabel, IonInput, IonButton, IonIcon,
    IonNote, IonToggle, IonSelect, IonSelectOption, IonDatetime
  ],
})
export class CadastroPage implements OnInit {

 
  todasCaracteristicas: CaracteristicaModel[] = [];
  hoje = new Date().toISOString();
  
  showSenha = signal(false);
  showConfirmarSenha = signal(false);

  // O formGroup casa 1-para-1 com os formControlName do HTML
  formGroup: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private usuarioService: UsuarioService,
    private caracteristicaService: CaracteristicaService,
    private toastController: ToastController,
    private navController: NavController,
  ) {
    addIcons({
      arrowBackOutline, eyeOutline, eyeOffOutline,
      personOutline, mailOutline, lockClosedOutline,
      calendarOutline, cardOutline, locationOutline,
      briefcaseOutline, personAddOutline,
    });

    this.formGroup = this.formBuilder.group({
      nome: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      senha: ['', [Validators.required, Validators.minLength(3)]],
      confirmarSenha: ['', Validators.required],
      dtNasc: ['', Validators.required],
      cpf: ['', [Validators.required, Validators.minLength(11)]],
      cep: ['', Validators.required],
      caracteristicas: [[]],
      isProfissional: [false],
    });
  }

  ngOnInit() {
    // Carrega as características disponíveis para o ion-select
    this.todasCaracteristicas = this.caracteristicaService.listar();
  }

  toggleSenha() { this.showSenha.update(v => !v); }
  toggleConfirmarSenha() { this.showConfirmarSenha.update(v => !v); }

  async salvar() {
    // Pega os valores do form
    const v = this.formGroup.value;

    // --- Validações manuais ---

    if (!v.nome?.trim()) {
      await this.exibirMensagem('Informe seu nome completo.'); return;
    }

    if (!v.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) {
      await this.exibirMensagem('Informe um e-mail válido.'); return;
    }

    if (!v.senha || v.senha.length < 3) {
      await this.exibirMensagem('A senha deve ter no mínimo 3 caracteres.'); return;
    }

    if (v.senha !== v.confirmarSenha) {
      await this.exibirMensagem('As senhas não coincidem.'); return;
    }


    if (!v.cpf || v.cpf.replace(/\D/g, '').length < 11) {
      await this.exibirMensagem('Informe um CPF válido.'); return;
    }

    if (!v.cep || v.cep.replace(/\D/g, '').length < 8) {
      await this.exibirMensagem('Informe um CEP válido.'); return;
    }

    // --- Monta e salva o usuário ---

    const usuario = new UsuarioModel();
    usuario.nome = v.nome;
    usuario.email = v.email;
    usuario.senha = v.senha;
    usuario.cpf = v.cpf;
    usuario.dtNasc = v.dtNasc;
    usuario.endereco.cep = v.cep;
    usuario.caracteristicas = v.caracteristicas ?? [];
    usuario.tipo = v.isProfissional ? 'PROFISSIONAL' : 'CLIENTE';

    this.usuarioService.salvar(usuario).subscribe({
      next: async (usuario) => {
        if (usuario.tipo === 'PROFISSIONAL') {
          this.navController.navigateForward(`/add-servico/${usuario.id}`);
          return;
        }
        await this.exibirMensagem('Conta criada com sucesso!');
        this.navController.navigateRoot('/login');
      },
      error: (err) => {
        console.log("Erro ao salvar: ", err)
        console.log("Usuario que foi 'salvo': ", usuario)
        console.log("DtNasc: ", usuario.dtNasc)
        this.exibirMensagem("Erro ao salvar");
      }
    });


  }

  async exibirMensagem(texto: string) {
    const toast = await this.toastController.create({
      message: texto,
      duration: 2000,
    });
    toast.present();
  }

  mascaraCpf(event: any) {
    let valor = event.target.value;

    valor = valor.replace(/\D/g, ''); // remove tudo que não for número

    valor = valor.replace(/^(\d{3})(\d)/, '$1.$2');
    valor = valor.replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3');
    valor = valor.replace(/\.(\d{3})(\d)/, '.$1-$2');

    this.formGroup.patchValue({
      cpf: valor
    }, { emitEvent: false });
  }


  mascaraCep(event: any) {
    let valor = event.target.value;

    valor = valor.replace(/\D/g, '');

    valor = valor.replace(/^(\d{5})(\d)/, '$1-$2');

    this.formGroup.patchValue({
      cep: valor
    }, { emitEvent: false });
  }

}